require('dotenv').config();

require('./app');

require('./migrations');
